Creator
~~~~~~~

-  Isaak Uchakaev `(lk-geimfari)`_

Maintainers
~~~~~~~~~~~

-  Isaak Uchakaev `(lk-geimfari)`_
-  Sobolev Nikita `(sobolevn)`_

Inspirer
~~~~~~~~

-  Sobolev Nikita `(sobolevn)`_

Special thanks
~~~~~~~~~~~~~~

-  Sobolev Nikita `(sobolevn)`_
-  Kevin Schellenberg `(wikkiewikkie)`_
-  Ryan Varley `(ryanvarley)`_
-  Ruslan Valerievich `(Valerievich)`_
-  dy `(duckyou)`_
-  Emilio Cecchini `(ceccoemi)`_

Patches and Suggestions
~~~~~~~~~~~~~~~~~~~~~~~

-  Kevin Schellenberg `(wikkiewikkie)`_
-  Casey Weed `(Battleroid)`_
-  Alessandro Martini `(martini97)`_
-  Amin Alaee `(aminalaee)`_
-  Baurzhan Muftakhidinov `(crayxt)`_
-  Benjamin Schwarze `(benjixx)`_
-  Bill DeRusha `(bderusha)`_
-  David Poggi `(drpoggi)`_
-  Eliz Kiliç `(el)`_
-  Flavio Curella `(fcurella)`_
-  FliegendeWurst `(FliegendeWurst)`_
-  Gustavo Sampaio `(GustavoKatel)`_
-  JLWT90 `(jlwt90)`_
-  Jack McMorrow `(jackmcmorrow)`_
-  Jakub Wilk `(jwilk)`_
-  Jeremy Costava `(Costava)`_
-  Jin Yang `(redus)`_
-  Json701 `(jasonwaiting-dev)`_
-  Jérôme Christ `(jeromechrist)`_
-  Jürg Rast `(jrast)`_
-  Michael Crilly `(mrcrilly)`_
-  Michael Hand `(mipaaa)`_
-  Paul Walters `(PaulWaltersDev)`_
-  Philipp Offermann `(offermann)`_
-  Sobolev Nikita `(sobolevn)`_
-  Rafael Passos `(auyer)`_
-  Ranwise `(ranwise)`_
-  Sambuddha Basu `(sammyshj)`_
-  Thomas Carroll `(Uncleleech)`_
-  Tsimpitas Dimitris `(TsimpDim)`_
-  Vladislav Glinsky `(cl0ne)`_
-  Yn-Coder `(yn-coder)`_
-  Dmytro Zelinskyi `(zelds)`_
-  axcel `(axce1)`_
-  Ruslan Valerievich `(Valerievich)`_
-  Simon `(DefaltSimon)`_
-  dy `(duckyou)`_
-  Arvind Prasanna `(aprasanna)`_
-  Pavel Kasyanov `(RaidoS)`_
-  Valentin Gorbachev `(Vlangf)`_
-  Oleg Smedyuk `(conformist-mw)`_
-  e-vandenberg `(e-vandenberg)`_
-  Przemysław Pietras `(destag)`_
-  Wiktor Matuszewski `(pywkm)`_
-  Sadie Bartholomew `(sadielbartholomew)`_
-  Nazar Oleksiuk `(DevAerial)`_
-  Ivan Ramos `(expandedmind)`_
-  Jack Henry `(jackhenry)`_
-  Nikita Serba `(Nekit10)`_
-  Julien Surloppe `(jsurloppe)`_
-  Emilio Cecchini `(ceccoemi)`_
-  Anphisa `(anphisa)`_
-  Gary Donovan `(garyd203)`_
-  Shanmuga Priya R `(Shanmugapriya03)`_
-  Jeffrey Wilges `(jwilges)`_
-  Tim Kreitner `(tabassco)`_
-  Miroslav Šedivý `(eumiro)`_
-  Yusan `(aekt)`_
-  Emil Madsen `(Skeen)`_
-  Michael Oliver `(michael0liver)`_
-  Oleg Höfling `(hoefling)`_
-  Nick Pope `(ngnpope)`_
-  Arul Prabakaran `(arulprabakaran)`_
-  Florian Kroiß `(Wooza)`_
-  Han Wang `(freddiewanah)`_
-  David Gorup `(CerealKiller0807)`_
- Taha Zerrouki `(linuxscout)`_
- Yahia Abdeldjallil Benamrouche `(yah04dev)`_
- Watheq Alshowaiter `(watheqAlshowaiter)`_
- Zayed Alsaidi `(zayedalsaidi)`_
- Muayyad AlSadi `(muayyadalsadi)`_


.. _(lk-geimfari): https://github.com/lk-geimfari
.. _(sobolevn): https://github.com/sobolevn
.. _(duckyou): https://github.com/duckyou
.. _(wikkiewikkie): https://github.com/wikkiewikkie
.. _(ryanvarley): https://github.com/ryanvarley
.. _(Valerievich): https://github.com/Valerievich
.. _(Battleroid): https://github.com/Battleroid
.. _(martini97): https://github.com/martini97
.. _(aminalaee): https://github.com/aminalaee
.. _(crayxt): https://github.com/crayxt
.. _(benjixx): https://github.com/benjixx
.. _(bderusha): https://github.com/bderusha
.. _(drpoggi): https://github.com/drpoggi
.. _(el): https://github.com/el
.. _(fcurella): https://github.com/fcurella
.. _(FliegendeWurst): https://github.com/FliegendeWurst
.. _(jlwt90): https://github.com/jlwt90
.. _(jackmcmorrow): https://github.com/jackmcmorrow
.. _(jwilk): https://github.com/jwilk
.. _(Costava): https://github.com/Costava
.. _(redus): https://github.com/redus
.. _(jasonwaiting-dev): https://github.com/jasonwaiting-dev
.. _(jeromechrist): https://github.com/jeromechrist
.. _(mrcrilly): https://github.com/mrcrilly
.. _(mipaaa): https://github.com/mipaaa
.. _(PaulWaltersDev): https://github.com/PaulWaltersDev
.. _(offermann): https://github.com/offermann
.. _(auyer): https://github.com/auyer
.. _(ranwise): https://github.com/ranwise
.. _(sammyshj): https://github.com/sammyshj
.. _(Uncleleech): https://github.com/Uncleleech
.. _(TsimpDim): https://github.com/TsimpDim
.. _(cl0ne): https://github.com/cl0ne
.. _(yn-coder): https://github.com/yn-coder
.. _(zelds): https://github.com/zelds
.. _(axce1): https://github.com/axce1
.. _(DefaltSimon): https://github.com/DefaltSimon
.. _(aprasanna): https://github.com/aprasanna
.. _(RaidoS): https://github.com/RaidoS
.. _(Vlangf): https://github.com/Vlangf
.. _(conformist-mw): https://github.com/conformist-mw
.. _(e-vandenberg): https://github.com/e-vandenberg
.. _(destag): https://github.com/destag
.. _(pywkm): https://github.com/pywkm
.. _(GustavoKatel): https://github.com/GustavoKatel
.. _(sadielbartholomew): https://github.com/sadielbartholomew
.. _(DevAerial): https://github.com/DevAerial
.. _(expandedmind): https://github.com/ExpandedMind
.. _(lucasmarcel): https://github.com/lucasmarcel
.. _(jackhenry): https://github.com/jackhenry
.. _(Nekit10): https://github.com/Nekit10
.. _(jsurloppe): https://github.com/jsurloppe
.. _(ceccoemi): https://github.com/ceccoemi
.. _(anphisa): https://github.com/Anphisa
.. _(garyd203): https://github.com/garyd203
.. _(Shanmugapriya03): https://github.com/Shanmugapriya03
.. _(jwilges): https://github.com/jwilges
.. _(jrast): https://github.com/jrast
.. _(tabassco): https://github.com/tabassco
.. _(eumiro): https://github.com/eumiro
.. _(aekt): https://github.com/aekt
.. _(michael0liver): https://github.com/aekt
.. _(Skeen): https://github.com/Skeen
.. _(hoefling): https://github.com/hoefling
.. _(ngnpope): https://github.com/ngnpope
.. _(arulprabakaran): https://github.com/arulprabakaran
.. _(Wooza): https://github.com/Wooza
.. _(freddiewanah): https://github.com/freddiewanah
.. _(CerealKiller0807): https://github.com/CerealKiller0807
.. _(zayedalsaidi): https://github.com/zayedalsaidi
.. _(linuxscout): https://github.com/linuxscout
.. _(watheqAlshowaiter): https://github.com/watheqAlshowaiter
.. _(yah04dev): https://github.com/yah04dev
.. _(muayyadalsadi): https://github.com/muayyad-alsadi

