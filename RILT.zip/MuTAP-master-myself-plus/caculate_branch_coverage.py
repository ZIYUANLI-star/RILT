"""
Branch:分支总数
BrPart:为覆盖到的分支数


"""


# -*- coding: utf-8 -*-
import textwrap
import os
import sys
import subprocess
import coverage


def run_tests_with_coverage(input_file_path, coverage_file_path):
    temp_dir_path = os.path.join(os.getcwd(), "temp_dir")
    if not os.path.exists(temp_dir_path):
        os.mkdir(temp_dir_path)

    # 读取输入文件并分离代码和测试部分
    with open(input_file_path, encoding='utf-8', errors='ignore') as input_file:
        function_to_correct = input_file.read()

    output = function_to_correct.split("def test():")
    test_code=output[1]
    lines = test_code.splitlines()
    filtered_lines = [line for line in lines if line.strip() != "from __future__ import annotations"]
    test_code = "\n".join(filtered_lines)
    code = output[0]



    test = (
        "import sys\n"
        f"temp_dir = r'{temp_dir_path}'\n"  # 使用原始字符串表示路径
        "sys.path.insert(0, temp_dir)\n"
        "import unittest\n"
        "from code_under_test import *\n"
        "def test():\n" +
        test_code +
        "\nif __name__ == '__main__':\n"
        "    unittest.main()"
    )

    # 写入代码文件
    code_file_path = os.path.join(temp_dir_path, "code_under_test.py")
    with open(code_file_path, "w",encoding='utf-8') as code_under_test:
        code_under_test.write(code)

    # 写入测试文件
    test_file_path = os.path.join(temp_dir_path, "test_code.py")
    with open(test_file_path, "w",encoding='utf-8') as test_code:
        test_code.write(test)

    # 使用子进程运行测试以隔离缓存和收集覆盖率
    command = [
        sys.executable,
        "-c",
        textwrap.dedent(f"""
            import importlib.util
            import traceback
            import unittest
            import sys
            import os
            import coverage

            # 启动覆盖率
            cov = coverage.Coverage(data_file=r'{coverage_file_path}', branch=True)
            cov.start()

            temp_dir = r'{temp_dir_path}'  # 使用原始字符串表示路径
            sys.path.insert(0, temp_dir)

            module_file_path = os.path.join(temp_dir, "code_under_test.py")
            test_file_path = os.path.join(temp_dir, "test_code.py")

            try:
                spec = importlib.util.spec_from_file_location("module", module_file_path)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)

                spec_test = importlib.util.spec_from_file_location("test_module", test_file_path)
                test_module = importlib.util.module_from_spec(spec_test)
                spec_test.loader.exec_module(test_module)

                if hasattr(test_module, 'test'):
                    print(f"Running test() function in {{test_file_path}}")
                    test_module.test()
                else:
                    print(f"No test() function found in {{test_file_path}}")
            except Exception as e:
                print(f"An error occurred while running tests: {{e}}")
                traceback.print_exc()
            finally:
                # 停止覆盖率跟踪并保存
                cov.stop()
                cov.save()
                print("Generating coverage report:")
                cov.report(show_missing=True)
                cov.html_report(directory='coverage_html_report')

        """)
    ]
    try:
        subprocess.run(command, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Subprocess failed with error: {e}")


def calculate_coverage_for_files(path):
    i = 0
    total_statements = 0
    missing_statements = 0
    total_branches=0
    missing_branches=0
    for root, dirs, files in os.walk(path):
        for filename in files:
            if filename.endswith('_timer_Timer_unit_test_Recover_merge_all.py'):
                print(f"Processing file {i}: {filename}")
                i += 1
                file_path = os.path.join(root, filename)

                # 创建一个唯一的覆盖率文件路径
                coverage_file_path = f".coverage_{i}"

                # 运行测试并生成覆盖率数据
                run_tests_with_coverage(file_path, coverage_file_path)

                # 加载覆盖率数据进行分析
                cov = coverage.Coverage(data_file=coverage_file_path)
                cov.load()  # 加载覆盖率数据

                analysis = cov.analysis2(
                    os.path.join(os.getcwd(), "temp_dir", "code_under_test.py")
                )
                _, statements, _, missing, _ = analysis

                total_statements += len(statements)
                missing_statements += len(missing)


                # 清理覆盖率对象
                cov.erase()




if __name__ == "__main__":
    path = r"D:\postgradute_Learning\paper\exam\MuTAP-master-myself-plus\HumanEval\item\apimd-master_test\Code_Unit"
    calculate_coverage_for_files(path)
